/* 
 * File:   eprom.h
 * Author: hp
 *
 * Created on 24 May, 2026, 7:57 PM
 */

#ifndef EPROM_H
#define	EPROM_H

void write_internal_eeprom(unsigned char address, unsigned char data); 
unsigned char read_internal_eeprom(unsigned char address);

#endif	/* EPROM_H */

