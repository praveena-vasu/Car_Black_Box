/* 
 * File:   main.h
 * Author: hp
 *
 * Created on 25 May, 2026, 5:59 PM
 */

#ifndef MAIN_H
#define	MAIN_H

extern unsigned int max_event_count;
extern unsigned int hour;
extern unsigned int min;
extern unsigned int sec;

#endif	/* MAIN_H */

